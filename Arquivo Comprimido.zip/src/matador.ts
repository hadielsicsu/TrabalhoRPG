import { personagem } from "./Personagem";

export class matador extends personagem{
    

    constructor(nome:string){
      super (nome)

}
}