
interface Personagem {
    alcanceMaximo: number;
  }
  
  interface GuerreiroCorpoACorpo extends Personagem {
    alcanceMaximo: 2;
  }
  
  interface GuerreiroLongoAlcance extends Personagem {
    alcanceMaximo: 20;
  }
  
  class Alvo {
    receberDano() {
      console.log('Alvo recebeu dano!');
    }
  }
  
  function causarDano(personagem: Personagem, alvo: Alvo) {
    if (personagem.alcanceMaximo >= calcularDistancia(personagem, alvo)) {
      alvo.receberDano();
    } else {
      console.log('O alvo está fora do alcance do personagem!');
    }
  }
  
  function calcularDistancia(personagem: Personagem, alvo: Alvo): number {
    
    return Math.floor(Math.random() * personagem.alcanceMaximo) + 1;
  }
  
  
  const guerreiroCorpoACorpo: GuerreiroCorpoACorpo = {
    alcanceMaximo: 2,
  };
  
  const guerreiroLongoAlcance: GuerreiroLongoAlcance = {
    alcanceMaximo: 20,
  };
  
  