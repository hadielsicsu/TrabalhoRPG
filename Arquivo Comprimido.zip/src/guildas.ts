import { personagem } from "./Personagem"

export class guilda {
    membros: Set<personagem>

    constructor(){
        this.membros = new Set<personagem> ();
    }

adicionarMembro (membro:personagem){
    this.membros.add(membro);
}
removerMembro (membro:personagem){
    this.membros.delete(membro);
}

aliado(personagem:personagem){
    return this.membros.has(personagem);
}
}