import { personagem } from "./Personagem";

export class alcance extends personagem{
    

    constructor(nome:string){
        super (nome)
    }


} 
